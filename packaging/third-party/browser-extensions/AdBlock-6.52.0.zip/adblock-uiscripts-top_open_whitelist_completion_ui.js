/*
 * This file is part of AdBlock  <https://getadblock.com/>,
 * Copyright (C) 2013-present  Adblock, Inc.
 *
 * AdBlock is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * AdBlock is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdBlock.  If not, see <http://www.gnu.org/licenses/>.
 */

/* For ESLint: List any global identifiers used in this file below */
/* global browser, translate, bindEnterClickToDefault, mayOpenDialogUi:true, i18nJoin,
   processReplacementChildrenInContent, setLangAndDirAttributes, loadWizardResources */

// Global lock so we can't open more than once on a tab.
if (typeof window.mayOpenDialogUi === "undefined") {
  window.mayOpenDialogUi = true;
}

// This script is injected each time the white list wizard is completed. Until we switch to ES6
// modules (aka import) we need to protect the code in a namespace so classes aren't declared
// multiple times.

// topOpenWhitelistUI displays the whitelist wizard completion page if it's not already open.
// See README for details.
/* eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars */
function topOpenWhitelistCompletionUI(options) {
  if (!mayOpenDialogUi) {
    return;
  }

  mayOpenDialogUi = false;

  // Get Flash objects out of the way of our UI
  browser.runtime.sendMessage({ command: "sendContentToBack" });

  // A empty base <div> is appended to the page's DOM and then a shadow is hosted in it.
  // The shadow protects our dialog from outside CSS "leaking" in.
  // Existing page styles are reset in the shadow at the top of `adblock-wizard.css`
  // using `:host` to select our base and the CCS rule `all:initial;` to perform the reset.
  const base = document.createElement("div");
  const $base = $(base.attachShadow({ mode: "open" }));

  loadWizardResources($base, () => {
    // check if we're running on website with a frameset, if so, tell
    // the user we can't run on it.
    if ($("frameset").length >= 1) {
      // eslint-disable-next-line no-alert
      alert(translate("wizardcantrunonframesets"));
      mayOpenDialogUi = true;
      return;
    }

    const html = `
    <div id="wizard">
      <header >
        <img aria-hidden="true" src="${browser.runtime.getURL("/icons/icon24.png")}">
        <h1 >${translate("whitelistertitle2")}</h1>
      </header>
      <section>
        <div class='messageWithLink' i18n_replacement_el='settings-link'>
          ${i18nJoin("successfully_whitelisted", "future_show_ads", "change_behavior_settings")}
          <a id='settings-link' class='link' href='#'></a>
        </div>
      </section>
      <section >
        <div>${translate("adblock_wont_run_on_pages_matching")}</div>
        <div dir="ltr" id="adblock-rule"></div>
      </section>
      <section class='body-button'>
        <button class='cancel'>${translate("done")}</button>
      </section>
    </div>
    `;

    const $dialog = $(html);
    const $adblockRule = $dialog.find("#adblock-rule");
    const $doneBtn = $dialog.find("button.cancel");
    const $settingsLink = $dialog.find("#settings-link");

    $adblockRule.text(options.rule || "");

    $doneBtn.on("click", () => {
      mayOpenDialogUi = true;
      (document.body || document.documentElement).removeChild(base);
    });
    $settingsLink.on("click", () => {
      browser.runtime.sendMessage({
        command: "openTab",
        urlToOpen: browser.runtime.getURL("options.html#customize"),
      });
    });

    $dialog.find(".messageWithLink").each(function replaceLinks() {
      processReplacementChildrenInContent($(this));
    });

    setLangAndDirAttributes($dialog.get(0));
    bindEnterClickToDefault($dialog);

    // Show page
    $base.append($dialog);
  });
  (document.body || document.documentElement).appendChild(base);
}

// required return value for tabs.executeScript
/* eslint-disable-next-line no-unused-expressions */
("");

//# sourceURL=/uiscripts/top_open_whitelist_ui.js
